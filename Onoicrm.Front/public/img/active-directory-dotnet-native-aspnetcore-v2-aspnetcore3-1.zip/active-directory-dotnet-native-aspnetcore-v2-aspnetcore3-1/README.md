---
languages:
  - csharp
products:
  - aspnet
  - azure
  - azure-active-directory
page_type: sample
urlFragment: aspnetcore-web-api-quickstart
description: "Quickstart - protect an ASP.NET Core Web API with the Microsoft identity platform."
---

# Quickstart: Protect an ASP.NET Core web API with Microsoft identity platform

This is the code for the ASP.NET Core Web API quickstart: See https://docs.microsoft.com/azure/active-directory/develop/quickstart-v2-aspnet-core-webapi.
